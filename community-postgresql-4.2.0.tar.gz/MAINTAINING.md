# Maintaining this collection

Refer to the [Maintainer guidelines](https://docs.ansible.com/ansible/devel/community/maintainers.html).
